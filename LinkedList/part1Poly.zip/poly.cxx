//Logan McCaul Part 1
//polynode* head_ptr - The first node in the list. Has 0 as the coefficient and exponent
//polynode* tail_ptr - Always points to the last node in the list
//mutable polynode* recent_ptr - Changeable node that keeps track of the last pointer accessed
//unsigned int current_degree - Highest exponent in the list
#include "poly.h"
using namespace std;

namespace main_savitch_5
{
	//Constructor
	polynomial::polynomial(double c, unsigned int exponent)
	{
		// store machine epsilon
		EPSILON = std::numeric_limits<double>::epsilon();
		// Creates the headptr as a blank node
		head_ptr = new polynode(c,0);
		//Checks to see if another node needs to be created
		if(exponent == 0 || fabs(c) < EPSILON){
			recent_ptr = head_ptr;
			tail_ptr = head_ptr;
			current_degree = 0;
			//creates the headptr and th second node if necessary
		}else{
			head_ptr -> set_coef(0);
			polynode* p = new polynode(c, exponent, nullptr, head_ptr);
			head_ptr -> set_fore(p);
			tail_ptr = p;
			recent_ptr = p;
			current_degree = exponent;
		}
    }
	//Assignment operator
    polynomial& polynomial::operator=(const polynomial& source)
    {
		// store machine epsilon
		EPSILON = std::numeric_limits<double>::epsilon();
		//Makes sure the two polynomial being inputted aren't the same address
		if(this == &source)
			return *this;
		//removes the headptr and clears the rest of the nodes from the first polynomial
		if(head_ptr != nullptr)
			clear();
		delete head_ptr;
		head_ptr = nullptr;
		tail_ptr = nullptr;
		recent_ptr = nullptr;
		//copies over the values of one of the polynomials
		if(source.head_ptr != nullptr){
			head_ptr = new polynode(source.head_ptr->coef(), source.head_ptr->exponent());
			tail_ptr = head_ptr;
			recent_ptr = head_ptr;
			current_degree = 0;
		}
		//Copies each node
		for(unsigned int expo = source.next_term(0); expo != 0; expo = source.next_term(expo)){
			assign_coef(source.coefficient(expo),expo);
		}
		return *this;
	}
	
	//copy constructor
    polynomial::polynomial(const polynomial& source)
    {
		// store machine epsilon
		EPSILON = std::numeric_limits<double>::epsilon();
		//creates a shallow copy polynomial
		head_ptr = NULL;
		*this = source;
    }
//Deletes the polynodes and calls clear to remove each node
    polynomial::~polynomial()
    {
		clear();
		delete head_ptr;
		head_ptr = nullptr;
		tail_ptr = nullptr;
		recent_ptr = nullptr;
		current_degree = 0;
    }

//Steps trhough each node in the list and removes it's values
    void polynomial::clear()
    {
		polynode* temp = head_ptr;
		while(head_ptr -> fore() != nullptr){
			temp = head_ptr -> fore();
			delete head_ptr;
			head_ptr = temp;
		}
		head_ptr -> set_coef(0);
		head_ptr -> set_exponent(0);
		current_degree = 0;
		tail_ptr = head_ptr;
		recent_ptr = head_ptr;
    }
    
    //sets recent polynode
    double polynomial::coefficient(unsigned int exponent) const
    {
		set_recent(exponent);
		if (exponent == recent_ptr -> exponent())
			return recent_ptr -> coef();
		return 0;
    }

//add on to the coefficient of a specific polynode
    void polynomial::add_to_coef(double amount, unsigned int exponent)
    {
		set_recent(exponent);
		if(fabs(amount) < EPSILON && exponent > current_degree)
			return;
		else if(recent_ptr -> exponent() < exponent){
			polynode* temp = new polynode(amount, exponent, recent_ptr -> fore(), recent_ptr);
			if(recent_ptr -> fore() != nullptr)
				recent_ptr -> fore() -> set_back(temp);
			else
				tail_ptr = temp;
			recent_ptr->set_fore(temp);
			if(exponent > current_degree && fabs(amount) >= EPSILON)
				current_degree = exponent;
		}
		else if(exponent == 0){
			recent_ptr -> set_coef(recent_ptr -> coef() + amount);
		}
		else if(exponent == current_degree && fabs(amount + recent_ptr->coef()) < EPSILON){
			tail_ptr = recent_ptr -> back();
			delete recent_ptr;
			recent_ptr = tail_ptr;
			tail_ptr -> set_fore(nullptr);
			current_degree = tail_ptr -> exponent();
		}
		else if(exponent == current_degree && fabs(amount + recent_ptr -> coef()) > EPSILON)
			recent_ptr -> set_coef(recent_ptr -> coef() + amount);
		else if (exponent != current_degree && fabs(amount + recent_ptr->coef()) > EPSILON)
			recent_ptr -> set_coef(recent_ptr -> coef() + amount);
		else if (exponent != current_degree && fabs(amount + recent_ptr->coef()) < EPSILON){
			recent_ptr -> back() -> set_fore(recent_ptr -> fore());
			recent_ptr -> fore() -> set_back(recent_ptr -> back());
			delete recent_ptr;
			recent_ptr = recent_ptr -> back();
		}
	}

//change the coefficient of a specific polynode
    void polynomial::assign_coef(double coefficient, unsigned int exponent)
    {
		set_recent(exponent);
		if(fabs(coefficient) < EPSILON && exponent > current_degree)
			return;
		else if(recent_ptr -> exponent() < exponent){
			polynode* temp = new polynode(coefficient, exponent, recent_ptr -> fore(), recent_ptr);
			if(recent_ptr -> fore() != nullptr)
				recent_ptr -> fore() -> set_back(temp);
			else
				tail_ptr = temp;
			recent_ptr -> set_fore(temp);
			if (exponent > current_degree)
				current_degree = exponent;
			recent_ptr = temp;
		}
		else if(fabs(coefficient) > EPSILON ||  exponent == 0){
			recent_ptr -> set_coef(coefficient);
			if(exponent > current_degree)
				current_degree = exponent;
		}
		else if(exponent == current_degree){
			tail_ptr = recent_ptr -> back();
			delete recent_ptr;
			recent_ptr = tail_ptr;
			tail_ptr -> set_fore(nullptr);
			current_degree = tail_ptr -> exponent();
		}
		else{
			recent_ptr -> back() -> set_fore(recent_ptr -> fore());
			recent_ptr -> fore() -> set_back(recent_ptr -> back());
			delete recent_ptr;
			recent_ptr = recent_ptr -> back();
		}
			
    }
//Points recent to the next term in the list
    unsigned int polynomial::next_term(unsigned int exponent) const
    {
		if (exponent >= current_degree)
			return 0;
		set_recent(exponent);
		if(recent_ptr-> fore() == nullptr)
			return 0;
		return recent_ptr -> fore() -> exponent();
    }

//points to the previous term in the list
	unsigned int polynomial::previous_term(unsigned int exponent) const
    {
		if(exponent <= 0)
			return UINT_MAX;
		set_recent(exponent - 1);
		if(recent_ptr == nullptr)
			return UINT_MAX;
		if(fabs(recent_ptr -> coef()) < EPSILON && recent_ptr -> exponent() == 0)
			return UINT_MAX;
		else
			return recent_ptr -> exponent();
		return UINT_MAX;
    }
    
    //set what the recent_ptr is looking at
    void polynomial::set_recent(unsigned int exponent) const
    {
		if(exponent == 0)
			recent_ptr = head_ptr;
		else if(exponent >= current_degree)
			recent_ptr = tail_ptr;
		else if(exponent < recent_ptr->exponent()){
			while(exponent < recent_ptr->exponent())
				recent_ptr = recent_ptr -> back();
		}
		else{
			while(exponent > recent_ptr -> exponent())
				recent_ptr = recent_ptr -> fore();
		}
	}
    
    double polynomial::eval(double x) const
    {
		double total = 0;
		return total;
    }

    polynomial polynomial::derivative() const
    {
		polynomial p_prime;
		return p_prime;
    }
    
    polynomial operator+(const polynomial& p1, const polynomial& p2)
    {
		polynomial p;
		return p;
    }
    
    polynomial operator-(const polynomial& p1, const polynomial& p2)
    {
		polynomial p;
		return p;
    }
    
    polynomial operator*(const polynomial& p1, const polynomial& p2)
    {		
		polynomial p;
		return p;
    }

    ostream& operator << (ostream& out, const polynomial& p)
    {
		return out;
    }
    
    void polynomial::find_root(
	double& answer,
	bool& success,
	unsigned int& iterations,
	double guess,
	unsigned int maximum_iterations,
	double epsilon) const
    {
	}
}
